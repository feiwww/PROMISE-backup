package org.apache.poi.hssf.model;

/**
 * enclosing_type describe the purpose here
 * 
 * @author Andrew C. Oliver androliv@cisco.com
 */
public interface Model
{

}
