package org.apache.poi.hssf.record.formula;

public abstract class ControlPtg
        extends Ptg
{

}
