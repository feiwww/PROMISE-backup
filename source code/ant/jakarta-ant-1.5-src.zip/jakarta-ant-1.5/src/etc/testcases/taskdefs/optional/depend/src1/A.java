public class A extends B {
    private D d = new D();
}

