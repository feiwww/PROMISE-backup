QUICK NOTEPAD PLUGIN

The jEdit source distribution includes source code for an example plugin
named 'QuickNotepad', written by John Gellene.

The plugin source is discussed in detail in the 'Writing Plugins' part
of the user's guide.
