//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by jeditshell.rc
// $Id: Resource.h,v 1.2 2001/07/30 17:27:53 jgellene Exp $
#define IDS_PROJNAME                    100
#define IDI_JEDIT                       101
#define IDS_IJEDITLAUNCHER_DESC         201
#define IDS_REG_CTXMENU_KEY             202
#define IDR_IJEditLauncher31            301
#define IDR_IJEditLauncher32            302
#define IDR_IJEditCtxMenu				401
#define IDS_REG_PARAMS_KEY_3_1          1301
#define IDS_REG_PARAMS_KEY_3_2          1302
#define IDS_REG_PARAMS_KEY_3_3          1303
#define IDS_REG_PARAMS_KEY_3_4          1304
#define IDS_REG_PARAMS_KEY_3_5          1305
#define IDS_REG_PARAMS_KEY_3_6          1306
#define IDS_REG_PARAMS_KEY_3_7          1307
#define IDS_REG_PARAMS_KEY_3_8          1308
#define IDS_ERR_NO_WINSOCK              2001
#define IDS_ERR_NO_ENV                  2002
#define IDS_ERR_NO_SERVERFILE           2003
#define IDS_ERR_BAD_PORT                2004
#define IDS_ERR_BAD_KEY                 2005
#define IDS_ERR_BAD_SOCKET              2006
#define IDS_ERR_BAD_CONNECT             2007
#define IDS_ERR_NO_FILENAME             2008
#define IDS_ERR_REFUSE_CONNECT          2009
#define IDS_ERR_BAD_SERVERFILE          2010
#define IDS_ERR_NO_REGISTRY_KEY         2011
#define IDS_ERR_NO_JAVA_EXEC_VALUE      2012
#define IDS_ERR_NO_JEDIT_TARGET_VALUE   2013
#define IDS_ERR_NO_JEDIT_OPTIONS_VALUE  2014
#define IDS_ERR_NO_JEDIT_WORKINGDIR_VALUE 2015
#define IDS_ERR_NO_CTX                  2016
#define IDS_ERR_NO_CTX_SUBKEY           2017
#define IDS_ERR_NO_CTX_DATA             2018
#define IDS_ERR_NO_CTX_DELETE           2019
#define IDS_ERR_UNSPECIFIED             2020

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        208
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         202
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif

//#include "versions.h"
